#include<stdio.h>
#include<stdlib.h>

struct linkedList{
	int info;
	struct linkedList *link;
}*f,*l;

struct node *createNode(int x){
	struct linkedList *newNode = (struct linkedList*)malloc(sizeof(struct linkedList));
	if(newNode==NULL){
		printf("Memory Not Given!");
		return;
	}
	newNode->info = x;
	newNode->link = NULL;
	return newNode;
}

void insert(int x){
	struct linkedList *newNode = createNode(x);
	if(newNode==NULL){
		printf("Memory Not Given!");
		return;
	}

	
}

void deleteEnd(){
	if(f==NULL){
		printf("Empty!");
		return;
	}
	struct linkedList *save = f;
	while(save->link!=NULL){
		save = save->link;
	}
	free(save->link);
	save->link = NULL;
}

void display(){
	if(f==NULL){
		printf("Underflow!");
		return;
	}
	struct linkedList *save = f;
	while(save->link!=NULL){
		printf("%d\t",save->info);
		save = save->link;
	}
	printf("%d\t",save->info);
}

void main(){

	while(1){
		int choice,x,y,n;
		printf("\nMenu\n");
		printf("1.Insert\n2.Delete\n5.display\n6.Exit\n");
		printf("Enter Your Choice:\n");
		scanf("%d",&choice);
		
		switch(choice){
			case 1:
				printf("Enter Element to Insert in LinkedList:");
				scanf("%d",&x);
				insert(x);
				break;
			case 2:
				printf("Press to Delete at end:\n");	
				deleteEnd();
				break;
//			case 3:
//				printf("Enter Element to Peep:");
//				scanf("%d",&y);
//				printf("peep element is: %d\n",peep(y));
//				break;
//			case 4:
//				printf("Enter Index to change Element:");
//				scanf("%d",&y);
//				printf("Enter Element to chnage:");
//				scanf("%d",&n);
//				change(y,n);
//				break;
			case 5:
				display();
				break;
			case 6:
				exit(0);
				
		}
}
}
