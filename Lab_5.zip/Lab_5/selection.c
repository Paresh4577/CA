#include<stdio.h>
#include<stdlib.h>

void selection_sort(int a[],int n){
	int minj,minx,i,j;
	for(i=0;i<n;i++){
		minj = i;
		minx = a[i];
		for(j=i+1;j<n;j++){
			if(a[j]<minx){
				minj = j;
				minx = a[j];
			}
		if(minj!=i){
			a[minj] = a[i];
			a[i] = minx;
		   }
		}
	}
}

void main(){
	int a = {2,67,44,32,5,90};
	int n = 6;
	selection_sort(a,n);
	printf("Arary After Sorting:");
	for(i=0;i<n;i++){
		printf("[%d]",a[i]);
	}
}
