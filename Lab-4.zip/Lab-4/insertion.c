#include<stdio.h>
#include<stdlib.h>

void main(){
	int n,i;
	printf("Enter size of array:");
	scanf("%d",&n);
	
	int a[n];
	
	for(i=0;i<n;i++){
		printf("[%d]:",i);
		scanf("%d",&a[i]);
	}
	insertion(a,n);
	
	printf("Sorted Array:");
	for(i=0;i<n;i++){
		printf("%d ",a[i]);
	}
}

void insertion(int a[],int n){
	int i,key,j;
	for(i=1;i<n;i++){
		key=a[i];
		j=i;
		
	while(j>0 && a[j-1]>key){
		a[j] = a[j-1];
		j = j-1;
    }
    a[j] = key;
	}
	
	
}
