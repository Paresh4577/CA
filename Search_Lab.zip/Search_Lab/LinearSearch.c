#include<stdio.h>
#include<stdbool.h>

int linearsearch(int a[],int size,int value){
	int i;
	for(i=0;i<size;i++){
		if(a[i]==value){
			return i;
		}
		
	}
	return -1;
}

void main(){
	int ls,size,i;
	int search;
	
	printf("Enter Size of array:");
	scanf("%d",&size);
	int a[size];
	for(i=0;i<size;i++){
		printf("Enter [%d]",i);
		scanf("%d",&a[i]);
	}
	
	printf("Enter element you want to find:");
	scanf("%d",&search);
	
     ls = linearsearch(a,size,search);
	
	if(ls==-1){
		printf("Element Not Found!");
	}
	else{
		printf("This Element %d is found in this array at %d",search,ls);
	}
	
}
