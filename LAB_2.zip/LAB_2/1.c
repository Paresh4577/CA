#include<stdio.h>
#include<stdlib.h>
#define MAX 5

struct stack{
	int top;
	int stk[MAX];
}s;

void push(int x){

	if(s.top==MAX-1){
		printf("Overflow!");
	}
	else{
		s.top++;
		s.stk[s.top]=x;
	}
}

void pop(){
	if(s.top==-1){
		printf("Underflow!");
	}
	else{
		s.stk[s.top--];
	}
}

int peep(int y){
	if(s.top-y+1==-1){
		printf("ith element is not exist!");
	}
	else{
		return s.stk[s.top-y+1];
	}
}
void display(){
	int i;
	if(s.top==-1){
		printf("underflow!");
	}
	else{
		for(i=0;i<=s.top;i++){
		printf("%d\n",s.stk[i]);
	   }
	}
}

void change(int y,int n){
	if(y<=0 || y>s.top+1){
		printf("Invalid Syntax:");
		return;
	}
		s.stk[s.top-y+1]=n;
}

void main(){
	s.top = -1;
	
	while(1){
		int choice,x,y,n;
		printf("Menu\n");
		printf("1.push\n2.pop\n3.peep\n4.change\n5.display\n6.Exit\n");
		printf("Enter Your Choice:\n");
		scanf("%d",&choice);
		
		switch(choice){
			case 1:
				printf("Enter Element to push:");
				scanf("%d",&x);
				push(x);
				break;
			case 2:
				printf("Press to Pop:");
				pop();
				break;
			case 3:
				printf("Enter Element to Peep:");
				scanf("%d",&y);
				printf("peep element is: %d\n",peep(y));
				break;
			case 4:
				printf("Enter Index to change Element:");
				scanf("%d",&y);
				printf("Enter Element to chnage:");
				scanf("%d",&n);
				change(y,n);
				break;
			case 5:
				display();
				break;
			case 6:
				exit(0);
				
		}
	}
}
