#include<stdio.h>
#include<stdlib.h>
#define MAX 5

struct queue{
	int front,rear;
	int queue[MAX];
}q;

void enqueue(int x){
	if(q.rear==MAX-1){
		printf("Overflow!");
	}
	else{
		q.queue[++q.rear] =x;
	}
	if(q.front==-1){
		q.front=0;
	}
}

void display(){
	int i;
	if(q.front==-1){
		printf("Underflow!");
	}
	else{
		for(i=q.front;i<=q.rear;i++){
			printf("%d\n",q.queue[i]);
		}
	}
}

int dequeue(){
	int y = q.queue[q.front];
	if(q.front==-1){
		printf("Underflow!");
	}
	if(q.front==q.rear){
		q.front=-1;
		q.rear=-1;
		return y;
	}
	else{
		q.queue[q.front++];
		return y;
	}
}

void main(){
	q.front=-1;
	q.rear=-1;
	while(1){
		int choice,x,y,n;
		printf("Menu\n");
		printf("1.push\n2.pop\n3.peep\n4.change\n5.display\n6.Exit\n");
		printf("Enter Your Choice:\n");
		scanf("%d",&choice);
		
		switch(choice){
			case 1:
				printf("Enter Element to Enqueue:");
				scanf("%d",&x);
				enqueue(x);
				break;
			case 2:
				printf("Press to Dequeue:");
				
				printf("The Dequeue element is:%d",dequeue());
				break;
//			case 3:
//				printf("Enter Element to Peep:");
//				scanf("%d",&y);
//				printf("peep element is: %d\n",peep(y));
//				break;
//			case 4:
//				printf("Enter Index to change Element:");
//				scanf("%d",&y);
//				printf("Enter Element to chnage:");
//				scanf("%d",&n);
//				change(y,n);
//				break;
			case 5:
				display();
				break;
			case 6:
				exit(0);
				
		}
}
}
